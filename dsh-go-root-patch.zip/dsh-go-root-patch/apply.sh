#!/bin/sh
# Apply the dsh-Go root-backend patch. Run from the repository root.
set -e
[ -f app/pubspec.yaml ] || { echo "run me from the dsh-Go repo root"; exit 1; }
K=app/android/app/src/main/kotlin/io/github/ccch1mneyyy/dsh_app/phone
S=$(dirname "$0")
cp -v "$S/files/app/lib/phone/android_shell_channel.dart"       app/lib/phone/
cp -v "$S/files/app/lib/ui/phone/android_shell_page.dart"        app/lib/ui/phone/
cp -v "$S/files/$K/PhonePlugin.kt"                              "$K/"
cp -v "$S/files/$K/shell/ShellProtocol.kt"                      "$K/shell/"
cp -v "$S/files/$K/shell/AndroidShellController.kt"             "$K/shell/"
cp -v "$S/files/$K/shell/ShellRootBackend.kt"                   "$K/shell/"
echo
echo "patched. now: cd app && flutter pub get && flutter build apk --release --target-platform android-arm64"
