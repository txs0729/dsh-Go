package io.github.ccch1mneyyy.dsh_app.phone.shell

import android.content.Context
import io.github.ccch1mneyyy.dsh_app.phone.background.Bundles
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Root backend: launches the same AndroidShellMain control channel as self-ADB, but
 * through `su -c`, so the host process (and every job it spawns) runs as uid 0.
 *
 * Nothing here touches the Ubuntu/proot runtime: this only adds a third option to the
 * existing "Android Shell" channel next to Shizuku and self-ADB.
 */
internal class ShellRootBackend(private val context: Context, private val onChanged: () -> Unit) {
    private val guard = Any()
    @Volatile private var channel: ShellLink? = null
    @Volatile private var host: Process? = null

    /** Cached only. Opening settings must never spawn su, or a prompt would pop on browse. */
    fun status(): Map<String, Any?> {
        val link = channel
        return mapOf(
            "connected" to (link?.alive() == true),
            "granted" to (link?.uid == 0),
        )
    }

    /** Explicit request: the only path allowed to make the root manager prompt. */
    fun requestPermission(): Boolean {
        val probe = runCatching {
            ProcessBuilder("su", "-c", "id -u").redirectErrorStream(true).start()
        }.getOrNull() ?: return false
        return try {
            val out = probe.inputStream.bufferedReader().use { it.readText() }.trim()
            probe.waitFor(8, TimeUnit.SECONDS) && probe.exitValue() == 0 && out == "0"
        } catch (_: Exception) {
            false
        } finally {
            runCatching { probe.destroyForcibly() }
        }
    }

    fun connect(wanted: () -> Boolean): ShellConnection {
        synchronized(guard) {
            channel?.takeIf { it.alive() && wanted() }?.let { return ShellConnection(it) }
            retireLocked()
            if (!wanted()) return ShellConnection(errorCode = "cancelled")
        }
        var candidate: ShellLink? = null
        var process: Process? = null
        return try {
            val info = context.applicationInfo
            val classpath = (listOf(info.sourceDir) + info.splitSourceDirs.orEmpty()).joinToString(":")
            require(classpath.isNotBlank() && '\u0000' !in classpath)
            val quoted = "'" + classpath.replace("'", "'\\''") + "'"
            // Same shape as RootCommands.appProcess: one single command string for su -c.
            val command = "CLASSPATH=" + quoted + " exec /system/bin/app_process /system/bin " +
                AndroidShellMain::class.java.name
            process = ProcessBuilder("su", "-c", command).start()
            val proc = process
            val input = proc.inputStream
            val output = proc.outputStream
            var synced = false
            candidate = ShellLink("root", { request ->
                if (!synced) { ShellWire.sync(input); synced = true }
                ShellWire.write(output, Bundles.marshal(request))
                Bundles.unmarshal(ShellWire.read(input) ?: throw IOException("transportLost"))
            }, { proc.isAlive }, { runCatching { proc.destroyForcibly() } })
            if (!candidate.probe()) {
                candidate.close()
                process.destroyForcibly()
                return ShellConnection(errorCode = if (proc.isAlive) "identityChanged" else "permissionRequired")
            }
            synchronized(guard) {
                if (!wanted()) {
                    candidate.close()
                    process.destroyForcibly()
                    return ShellConnection(errorCode = "cancelled")
                }
                channel = candidate
                host = process
                return ShellConnection(candidate)
            }
        } catch (_: Exception) {
            candidate?.close()
            process?.let { runCatching { it.destroyForcibly() } }
            return ShellConnection(errorCode = "connectFailed")
        } finally {
            onChanged()
        }
    }

    fun disconnect() {
        synchronized(guard) { retireLocked() }
        onChanged()
    }

    private fun retireLocked() {
        channel?.close()
        channel = null
        host?.let { runCatching { it.destroyForcibly() } }
        host = null
    }
}
